# Matched comparisons

These two tables compare each of the 18 assigned debates with its retained NONE control at the same generator, topic, grounding, speaking order and block-one settings. Each row retains both actual run IDs. `ASSIGNED` identifies the treated actor; `OTHER` identifies a cooperative actor in that assigned debate.

`matched-rubric.csv` has 450 participant/topic/metric pairs. Each of the five 0–4 metrics is separate. Positive disruptive-rhetoric differences mean more disruption according to the automated judge; positive other rubric differences mean higher scores on those metrics. Blank scores remain unavailable rather than zero.

`matched-local.csv` has 270 participant/method pairs. It first averages original chunks within each speech, then the five speeches for that party within that debate. Raw abstained transformer scores remain included. VADER compound retains −1 to 1; Cardiff positive and DeBERTa support retain 0 to 1. These measure sentiment and stance separately from rubric quality.

The workbook's general Summary pools the three NONE topics in baseline rows, whereas each named assignment here belongs to one topic. Use these matched tables or filter source data by Topic for direct control comparisons. One assigned repetition and one strategy per topic support descriptive inspection only; topic and tactic are confounded. Differences do not establish tactic enactment, causal effects, human scoring accuracy or independent observations across speeches.
